from django.shortcuts import render, redirect, get_object_or_404
from .forms import UserForm, RegisterForm
from django.http import HttpResponse
from .models import  Student
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


users = [{'study': 'Робототехника для детей',
          'name': "Иванов Иван Иванович",
          'phone': "7948484848",
          'payment': "Оплата по СБП"}]


def register_view(request):
    if request.method == "POST":
        auth_form = RegisterForm(request.POST)
        if auth_form.is_valid():
            user = auth_form.save()
            login(request, user)
            return redirect('profile') # После регистрации сразу в профиль
    else:
        auth_form = RegisterForm()
    return render(request, 'register.html', {'auth_form': auth_form})


def login_view(request):
    if request.method == 'POST':
        u = request.POST.get('username')
        p = request.POST.get('password')
        user = authenticate(request, username=u, password=p)
        if user is not None:
            login(request, user)
            return redirect('profile') # Проверь, что в urls.py есть name='profile'
        else:
            # Если пароль неверный, можно добавить ошибку
            return render(request, 'login.html', {'error': 'Неверный логин или пароль'})
    return render(request, 'login.html')


@login_required
def profile_view(request):
    # Находим все записи курсов для текущего пользователя
    my_courses = Student.objects.filter(user=request.user)
    
    return render(request, 'profile.html', {
        'my_courses': my_courses
    })

def logout_view(request):
    logout(request)
    return redirect('/')


def index(request):
    return render(request, "index.html")


def catalog(request):
    return render(request, "catalog.html")


def contact(request):
    return render(request, "contact.html")


def sign_up(request, course_id=None):
    if request.method == "POST":
        userform = UserForm(request.POST)
        if userform.is_valid():
            Student.objects.create(
                user=request.user,
                name=userform.cleaned_data['name'],
                phone=userform.cleaned_data['phone'],
                payment_method=userform.cleaned_data['payment'],  
                course=int(userform.cleaned_data['study'])  
            )
            return redirect('profile')
        else:
            return HttpResponse('Invalid data')
    else:
        initial_data = {}
        if course_id:
            initial_data['study'] = course_id
        userform = UserForm(initial=initial_data)
    return render(request, 'sign_up.html', {'form': userform})

def records(request):
    students = Student.objects.all()
    return render(request, "records.html", context={'students': students})


def delete_student(request, id):
    student = get_object_or_404(Student, id=id)
    student.delete()
    return redirect('/records/')


def edit_student(request, id):
    student = get_object_or_404(Student, id=id)

    if request.method == 'POST':
        student.name = request.POST.get('name')
        student.phone = request.POST.get('phone')
        student.course = int(request.POST.get('course'))
        student.payment_method = request.POST.get('payment_method')
        student.save()
        return redirect('/records/')

    return render(request, 'edit.html', {'student': student})

@login_required
def cancel_course(request, pk):
    # Ищем запись по ID (pk), если не нашли — выдаст 404
    enrollment = get_object_or_404(Student, pk=pk)
    

    # Удалить запись может только тот, кто её создал (или админ)
    if enrollment.user == request.user:
        enrollment.status = 'cancelled' # Меняем статус на "Отменен"
        enrollment.save() # Сохраняем изменения в базе
    
    return redirect('profile') # Возвращаем пользователя обратно в профиль

def documents_view(request):
    return render(request, 'about/documents.html')

def info_view(request):
    return render(request, 'about/info.html')


def organization_view(request):
    return render(request, 'about/organization.html')

def standards_view(request):
    return render(request, 'about/standards.html')

def services_view(request):
    return render(request, 'about/services.html')


