from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    # 1. Какие колонки показывать в списке
    list_display = ('id', 'name', 'user', 'course', 'status', 'payment_method')
    
    # 2. По каким полям можно кликнуть, чтобы перейти в редактирование
    list_display_links = ('id', 'name')
    
    # 3. Фильтры справа (очень удобно!)
    list_filter = ('status', 'course', 'payment_method')
    
    # 4. Поиск (по ФИО, логину пользователя или телефону)
    search_fields = ('name', 'user__username', 'phone')
    
    # 5. Возможность быстро менять статус прямо в списке
    list_editable = ('status',)
    
    # 6. Группировка полей внутри карточки студента
    fieldsets = (
        ('Основная информация', {
            'fields': ('user', 'name', 'phone')
        }),
        ('Курс и оплата', {
            'fields': ('course', 'payment_method', 'status')
        }),
    )


