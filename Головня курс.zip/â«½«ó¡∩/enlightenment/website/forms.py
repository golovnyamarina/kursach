from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

STUDY = [
    ('', 'Выберите курс'),
    (1, 'Подготовка к ЕГЭ по информатике'),
    (2, "Предшкольная подготовка"),
    (3, 'Курсы английского языка для начинающих'),
    (4, 'Подготовка к ОГЭ по математике'),
    (5, 'Онлайн-занятия по русскому языку'),
    (6, 'Подготовка к ЕГЭ по биологии'),
    (7, 'Робототехника для детей'),
    (8, 'Изучение истории России')
]

PAYMENT = (
    ('', 'Выберите способ оплаты'),
    ('card', 'Оплата банковской картой'),
    ('cash', 'Оплата наличными'),
    ('sbp', 'Оплата по СБП')
)


class RegisterForm(UserCreationForm):
    username = forms.CharField(label="Логин")
    email = forms.EmailField(label="Email", required=True)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")


class UserForm(forms.Form):
    study = forms.ChoiceField(
        label='Наименование курса',
        choices=STUDY,
        required=True
    )
    name = forms.CharField(
        label='Имя',
        max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Введите ФИО'})
    )
    phone = forms.CharField(
        label='Телефон',
        max_length=20,
        widget=forms.TextInput(attrs={'placeholder': 'Введите телефон'})
    )
    payment = forms.ChoiceField(
        label='Способ оплаты',
        choices=PAYMENT,
        required=True
    )