from django.contrib import admin
from django.urls import path
from website import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('catalog/', views.catalog, name='catalog'),
    path('contact/', views.contact, name='contact'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('signup/<int:course_id>/', views.sign_up, name='course_signup_with_id'),
    path('records/', views.records, name='records'),
    path('delete/<int:id>/', views.delete_student, name='delete'),
    path('cancel-course/<int:pk>/', views.cancel_course, name='cancel_course'),
    path('edit/<int:id>/', views.edit_student, name='edit'),
    path('register/', views.register_view, name='register'), # Путь для регистрации
    path('login/', views.login_view, name='login'),          # Путь для входа
    path('logout/', views.logout_view, name='logout'),        # Пу['logout/']
    path('profile/', views.profile_view, name='profile'),
    path('about/organization/', views.organization_view, name='organization_main'),
    path('about/documents/', views.documents_view, name='about_documents'),
    path('about/info/', views.info_view, name='about_info'),
    path('about/standards/', views.standards_view, name='about_standards'),
    path('about/services/', views.services_view, name='about_services'),
]
