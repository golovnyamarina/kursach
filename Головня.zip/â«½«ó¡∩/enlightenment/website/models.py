from django.db import models


class Student(models.Model):
    COURSE_CHOICES = (
        (1, 'Подготовка к ЕГЭ по информатике'),
        (2, "Предшкольная подготовка"),
        (3, 'Курсы английского языка для начинающих'),
        (4, 'Подготовка к ОГЭ по математике'),
        (5, 'Онлайн-занятия по русскому языку'),
        (6, 'Подготовка к ЕГЭ по биологии'),
        (7, 'Робототехника для детей'),
        (8, 'Изучение истории России')
    )

    PAYMENT_METHODS = [
        ('card', 'Оплата банковской картой'),
        ('cash', 'Оплата наличными'),
        ('sbp', 'Оплата по СБП'),
    ]

    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    payment_method = models.CharField(
        max_length=20,
        choices=PAYMENT_METHODS,
        default='card'
    )
    course = models.IntegerField(choices=COURSE_CHOICES)

