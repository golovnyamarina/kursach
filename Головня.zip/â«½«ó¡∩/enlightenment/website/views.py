from django.shortcuts import render, redirect, get_object_or_404
from .forms import UserForm
from django.http import HttpResponse
from .models import  Student

users = [{'study': 'Робототехника для детей',
          'name': "Иванов Иван Иванович",
          'phone': "7948484848",
          'payment': "Оплата по СБП"}]


def index(request):
    return render(request, "index.html")


def catalog(request):
    return render(request, "catalog.html")


def contact(request):
    return render(request, "contact.html")


def sign_up(request):
    if request.method == "POST":
        userform = UserForm(request.POST)
        if userform.is_valid():
            
            from .models import Student
            Student.objects.create(
                name=userform.cleaned_data['name'],
                phone=userform.cleaned_data['phone'],
                payment_method=userform.cleaned_data['payment'],  
                course=int(userform.cleaned_data['study'])  
            )
            return redirect('/')
        else:
            return HttpResponse('Invalid data')

    userform = UserForm()
    return render(request, 'sign_up.html', {'form': userform})

def records(request):
    students = Student.objects.all()
    return render(request, "records.html", context={'students': students})


def delete_student(request, id):
    student = get_object_or_404(Student, id=id)
    student.delete()
    return redirect('/records/')


def edit_student(request, id):
    student = get_object_or_404(Student, id=id)

    if request.method == 'POST':
        student.name = request.POST.get('name')
        student.phone = request.POST.get('phone')
        student.course = int(request.POST.get('course'))
        student.payment_method = request.POST.get('payment_method')
        student.save()
        return redirect('/records/')

    return render(request, 'edit.html', {'student': student})