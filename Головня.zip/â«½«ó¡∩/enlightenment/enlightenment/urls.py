from django.contrib import admin
from django.urls import path
from website import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('catalog/', views.catalog, name='catalog'),
    path('contact/', views.contact, name='contact'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('records/', views.records, name='records'),
    path('delete/<int:id>/', views.delete_student, name='delete'),
    path('edit/<int:id>/', views.edit_student, name='edit'),
]
