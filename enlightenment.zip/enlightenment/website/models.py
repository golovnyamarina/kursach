from django.db import models
from django.contrib.auth.models import User

class Course(models.Model):
    CATEGORY_CHOICES = [
        ('extra', 'Доп.образование'),
        ('ege', 'Подготовка к ЕГЭ'),
        ('online', 'Онлайн-курсы'),
    ]

    name = models.CharField('Название курса', max_length=200)
    category = models.CharField('Категория', max_length=20, choices=CATEGORY_CHOICES, default='extra')
    short_description = models.CharField('Краткое описание', max_length=200, help_text='Отображается в карточке каталога')
    description = models.TextField('Описание курса', blank=True)
    price = models.DecimalField('Стоимость', max_digits=10, decimal_places=2, default=0)
    slots = models.PositiveIntegerField('Всего мест', default=20)
    start_date = models.CharField('Сроки проведения', max_length=100, default='Постоянно')
    is_active = models.BooleanField('Активен для записи', default=True)
    image = models.ImageField('Обложка', upload_to='courses/', blank=True, null=True)

    def is_full(self):
            # Считаем активных и на рассмотрении
            occupied = self.student_set.filter(status__in=['active', 'review']).count()
            return occupied >= self.slots
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Курс'
        verbose_name_plural = 'Курсы'

class Student(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='student_profile', null=True, blank=True)
    course = models.ForeignKey(Course, on_delete=models.PROTECT, verbose_name='Курс')
    PAYMENT_METHODS = [
        ('card', 'Оплата банковской картой'),
        ('cash', 'Оплата наличными'),
        ('sbp', 'Оплата по СБП'),
    ]
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    payment_method = models.CharField(
        max_length=20,
        choices=PAYMENT_METHODS,
        default='card'
    )
    STATUS_CHOICES = [
        ('review', 'На рассмотрении'),
        ('active', 'Активен'),
        ('cancelled', 'Отменен'),
        ('completed', 'Завершен'),
    ]
    
    status = models.CharField(
        'Статус обучения', 
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='review'
    )
    created_at = models.DateTimeField('Дата записи', auto_now_add=True, null=True)

    def __str__(self):
        return f"{self.name} - {self.get_course_display()} ({self.get_status_display()})"
    
    class Meta:
        ordering = ['-created_at']
