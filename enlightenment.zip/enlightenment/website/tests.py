from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from .models import Course, Student
from .forms import UserForm

class WebsiteTests(TestCase):
    def setUp(self):
        # Создаем тестовые данные
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.course = Course.objects.create(
            name="Тестовый курс", 
            slots=10, 
            price=1000
        )

    def test_homepage_accessible(self):
        """Проверяем, что главная страница открывается"""
        response = self.client.get(reverse('index'))
        self.assertEqual(response.status_code, 200)

    def test_signup_redirects_anonymous(self):
        """Проверяем, что анонима перекидывает на логин при попытке записи"""
        url = reverse('course_signup_with_id', kwargs={'course_id': self.course.id})
        response = self.client.get(url)
        # Проверяем редирект (302) на страницу логина
        self.assertRedirects(response, f'/login/?next={url}')

    def test_signup_accessible_for_logged_in(self):
        """Проверяем, что залогиненный пользователь видит форму записи"""
        self.client.login(username='testuser', password='password123')
        url = reverse('course_signup_with_id', kwargs={'course_id': self.course.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)


class AdminAccessTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Создаем обычного пользователя
        self.user = User.objects.create_user(username='student', password='password123')
        # Создаем администратора (staff)
        self.admin = User.objects.create_user(username='admin', password='adminpassword', is_staff=True)
        # Создаем тестовый курс для проверки редактирования
        self.course = Course.objects.create(name="Python Base", price=5000, slots=10)

    def test_admin_profile_denied_for_student(self):
        """Проверяем, что обычный юзер видит profile.html, а не админку"""
        self.client.login(username='student', password='password123')
        response = self.client.get(reverse('profile'))
        
        # Проверяем, что используется шаблон для ученика, а не для админа
        self.assertTemplateUsed(response, 'profile.html')
        self.assertTemplateNotUsed(response, 'profile_admin.html')

    def test_course_edit_denied_for_student(self):
        """Проверяем, что студент не может зайти на страницу редактирования курса"""
        self.client.login(username='student', password='password123')
        url = reverse('admin_course_edit', kwargs={'pk': self.course.pk})
        response = self.client.get(url)
        
        # Так как у тебя используется @user_passes_test, 
        # Django по умолчанию перекидывает на страницу логина
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response.url)

    def test_admin_can_access_manage_pages(self):
        """Проверяем, что админ спокойно заходит в управление курсами"""
        self.client.login(username='admin', password='adminpassword')
        url = reverse('admin_course_edit', kwargs={'pk': self.course.pk})
        response = self.client.get(url)
        
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_course_form.html')

class LogicAndValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='tester', password='password123')
        self.course = Course.objects.create(name="Django Pro", price=100, slots=5)
        # Создаем готовую запись для теста отмены
        self.student_record = Student.objects.create(
            user=self.user,
            name="Тест Тестович",
            phone="88005553535",
            course=self.course,
            status='active'
        )

    def test_phone_validation_error(self):
        """Проверяем, что форма не примет буквы в поле телефона (если в форме стоит валидация)"""
        form_data = {
            'name': 'Иван',
            'phone': 'привет я не цифра',  # Невалидные данные
            'study': self.course.id,
            'payment': 'sbp'
        }
        form = UserForm(data=form_data)
        # Если в UserForm у тебя прописана валидация телефона, этот тест покажет ошибку
        self.assertFalse(form.is_valid())
        self.assertIn('phone', form.errors)

    def test_cancel_course_logic(self):
        """Проверяем, что при отмене статус меняется на 'cancelled'"""
        self.client.login(username='tester', password='password123')
        
        # Переходим по URL отмены курса
        url = reverse('cancel_course', kwargs={'pk': self.student_record.pk})
        response = self.client.get(url)
        
        # Проверяем редирект в профиль
        self.assertRedirects(response, reverse('profile'))
        
        # Обновляем объект из базы данных и проверяем статус
        self.student_record.refresh_from_db()
        self.assertEqual(self.student_record.status, 'cancelled')

    def test_cannot_cancel_others_course(self):
        """Проверяем, что чужой человек не может отменить твою запись"""
        # Создаем "злоумышленника"
        hacker = User.objects.create_user(username='hacker', password='123')
        self.client.login(username='hacker', password='123')
        
        url = reverse('cancel_course', kwargs={'pk': self.student_record.pk})
        self.client.get(url)
        
        # Статус НЕ должен измениться, так как во views.py есть проверка: if enrollment.user == request.user
        self.student_record.refresh_from_db()
        self.assertNotEqual(self.student_record.status, 'cancelled')
        self.assertEqual(self.student_record.status, 'active')

        def test_cannot_signup_if_course_is_full(self):
        # Создаем курс, где 0 свободных мест
            full_course = Course.objects.create(name="Полный курс", slots=0, price=100)
            self.client.login(username='tester', password='password123')
            
            url = reverse('course_signup_with_id', kwargs={'course_id': full_course.id})
            response = self.client.get(url)
            
            # Проверяем, что нас выкинуло обратно на страницу курса (как написано в твоем view)
            self.assertRedirects(response, reverse('course_detail', kwargs={'pk': full_course.id}))

            def test_signup_form_initial_course(self):
                """Проверяем, что в форме предвыбран правильный курс"""
                self.client.login(username='tester', password='password123')
                url = reverse('course_signup_with_id', kwargs={'course_id': self.course.id})
                response = self.client.get(url)
                
                # Проверяем, что в контексте шаблона лежит форма с начальным значением курса
                form = response.context['form']
                self.assertEqual(int(form.initial['study']), self.course.id)

            def test_admin_can_delete_student(self):
                """Проверяем, что админ может удалить запись студента"""
                self.client.login(username='admin', password='adminpassword') # Логинимся под админом
                
                # Создаем запись для удаления
                student_to_del = Student.objects.create(
                    user=self.user, name="Удаляшка", phone="123", course=self.course
                )
                
                url = reverse('admin_delete_request', kwargs={'pk': student_to_del.pk})
                response = self.client.get(url)
                
                # Проверяем редирект и отсутствие записи в базе
                self.assertRedirects(response, reverse('profile'))
                self.assertFalse(Student.objects.filter(pk=student_to_del.pk).exists())

