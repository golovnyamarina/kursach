from django.contrib import admin
from .models import Student, Course 

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'price', 'slots', 'start_date')

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'user', 'course', 'status', 'payment_method')
    
    list_display_links = ('id', 'name')
    
    list_filter = ('status', 'course', 'payment_method')
    
    # Поиск (по ФИО, логину пользователя или телефону)
    search_fields = ('name', 'user__username', 'phone')
    
    #Возможность быстро менять статус прямо в списке
    list_editable = ('status',)
    
    # Группировка полей внутри карточки студента
    fieldsets = (
        ('Основная информация', {
            'fields': ('user', 'name', 'phone')
        }),
        ('Курс и оплата', {
            'fields': ('course', 'payment_method', 'status')
        }),
    )


