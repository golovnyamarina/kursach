from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Course

STUDY = [
    ('', 'Выберите курс'),
    (1, 'Подготовка к ЕГЭ по информатике'),
    (2, "Предшкольная подготовка"),
    (3, 'Курсы английского языка для начинающих'),
    (4, 'Подготовка к ОГЭ по математике'),
    (5, 'Онлайн-занятия по русскому языку'),
    (6, 'Подготовка к ЕГЭ по биологии'),
    (7, 'Робототехника для детей'),
    (8, 'Изучение истории России')
]

PAYMENT = (
    ('', 'Выберите способ оплаты'),
    ('card', 'Оплата банковской картой'),
    ('cash', 'Оплата наличными'),
    ('sbp', 'Оплата по СБП')
)


class RegisterForm(UserCreationForm):
    username = forms.CharField(label="Логин")
    email = forms.EmailField(label="Email", required=True)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")


class UserForm(forms.Form):
    study = forms.ModelChoiceField(
        queryset=Course.objects.filter(is_active=True),
        label='Выберите курс',
        empty_label="Выберите курс из списка",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    name = forms.CharField(
        label='Имя',
        max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Введите ФИО'})
    )
    phone = forms.CharField(
        label='Телефон',
        max_length=20,
        widget=forms.TextInput(attrs={'placeholder': 'Введите телефон'})
    )
    payment = forms.ChoiceField(
        label='Способ оплаты',
        choices=PAYMENT,
        required=True
    )

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ("name", "short_description",
                   "description", "price",
                     "slots", "start_date",
                       "image", "is_active")
        labels = {
            'name': 'Название курса',
            'short_description': 'Краткое описание (для карточки)',
            'description': 'Полное описание (для страницы курса)',
            'price': 'Стоимость (руб.)',
            'slots': 'Всего мест в группе',
            'start_date': 'Сроки проведения',
            'image': 'Обложка курса',
            'is_active': 'Доступен для записи'
        }
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'short_description': forms.TextInput(attrs={'placeholder': 'Пара предложений для каталога'}),
            'start_date': forms.TextInput(attrs={'placeholder': 'например, 01.09 - 31.05'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-input'})