from django.shortcuts import render, redirect, get_object_or_404
from .forms import UserForm, RegisterForm, CourseForm
from django.http import HttpResponse
from .models import  Student, Course
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test


users = [{'study': 'Робототехника для детей',
          'name': "Иванов Иван Иванович",
          'phone': "7948484848",
          'payment': "Оплата по СБП"}]


def register_view(request):
    if request.method == "POST":
        auth_form = RegisterForm(request.POST)
        if auth_form.is_valid():
            user = auth_form.save()
            login(request, user)
            return redirect('profile') # После регистрации сразу в профиль
    else:
        auth_form = RegisterForm()
    return render(request, 'register.html', {'auth_form': auth_form})


def login_view(request):
    if request.method == 'POST':
        u = request.POST.get('username')
        p = request.POST.get('password')
        user = authenticate(request, username=u, password=p)
        if user is not None:
            login(request, user)
            return redirect('profile') 
        else:
            return render(request, 'login.html', {'error': 'Неверный логин или пароль'})
    return render(request, 'login.html')


@login_required
def profile_view(request):
    if request.user.is_staff:
        all_students = Student.objects.all()
        all_courses = Course.objects.all() 
        courses_with_stats = []
        for c in all_courses:
            occupied = Student.objects.filter(course=c, status__in=['active', 'review']).count()
            courses_with_stats.append({'course': c, 'occupied': occupied})

        stats = {
            'total': all_students.count(),
            'new': all_students.filter(status='review').count(),
            'active': all_students.filter(status='active').count(),
            'completed': all_students.filter(status='completed').count(),
        }

        grouped_data = []
        for course in all_courses:
            students = all_students.filter(course=course).order_by('-created_at')
            
            if students.exists():
                has_new = students.filter(status='review').exists()
                grouped_data.append({
                    'id': course.id,
                    'name': course.name,
                    'students': students,
                    'count': students.count(),
                    'has_new': has_new
                })

        # Добавляем 'all_courses_list' в словарь context
        return render(request, 'profile_admin.html', {
            'grouped_data': grouped_data,
            'stats': stats,
            'all_courses_list': courses_with_stats # Передаем список для блока управления
        })
    else:
        # Для обычного ученика
        my_courses = Student.objects.filter(user=request.user).select_related('course')
        return render(request, 'profile.html', {'my_courses': my_courses})

def logout_view(request):
    logout(request)
    return redirect('/')


def index(request):
    popular_courses = Course.objects.all()[:4] 
    return render(request, "index.html", {"popular_courses": popular_courses})


def catalog(request):
    courses = Course.objects.all()
    return render(request, "catalog.html", {"courses": courses})


def contact(request):
    return render(request, "contact.html")


from .models import Course, Student

def sign_up(request, course_id=None):
    if course_id:
        course = get_object_or_404(Course, id=course_id)
        # Если мест нет — выкидываем обратно на страницу курса
        if course.is_full():
            return redirect('course_detail', pk=course.id)
    if request.method == "POST":
        userform = UserForm(request.POST)
        if userform.is_valid():
            selected_course = userform.cleaned_data['study']
            
            Student.objects.create(
                user=request.user,
                name=userform.cleaned_data['name'],
                phone=userform.cleaned_data['phone'],
                payment_method=userform.cleaned_data['payment'],
                course=selected_course # Передаем целый объект!
            )
            return redirect('profile')
    else:
        # Для GET-запроса подставляем начальное значение
        initial_data = {}
        if course_id:
            initial_data['study'] = course_id
        userform = UserForm(initial=initial_data)
        
    return render(request, 'sign_up.html', {'form': userform})

def records(request):
    students = Student.objects.all()
    return render(request, "records.html", context={'students': students})


def delete_student(request, id):
    student = get_object_or_404(Student, id=id)
    student.delete()
    return redirect('/records/')


def edit_student(request, id):
    student = get_object_or_404(Student, id=id)

    if request.method == 'POST':
        student.name = request.POST.get('name')
        student.phone = request.POST.get('phone')
        student.course = int(request.POST.get('course'))
        student.payment_method = request.POST.get('payment_method')
        student.save()
        return redirect('/records/')

    return render(request, 'edit.html', {'student': student})

@login_required
def cancel_course(request, pk):
    enrollment = get_object_or_404(Student, pk=pk)
    

    if enrollment.user == request.user:
        enrollment.status = 'cancelled' 
        enrollment.save() 
    
    return redirect('profile') 

def documents_view(request):
    return render(request, 'about/documents.html')

def info_view(request):
    return render(request, 'about/info.html')


def organization_view(request):
    return render(request, 'about/organization.html')

def standards_view(request):
    return render(request, 'about/standards.html')

def services_view(request):
    return render(request, 'about/services.html')


def is_admin(user):
    return user.is_staff

# Изменение статуса админом
@user_passes_test(is_admin)
def admin_update_status(request, pk, status):
    enrollment = get_object_or_404(Student, pk=pk)
    enrollment.status = status
    enrollment.save()
    return redirect('profile')

# Полное удаление записи админом
@user_passes_test(is_admin)
def admin_delete_request(request, pk):
    enrollment = get_object_or_404(Student, pk=pk)
    enrollment.delete()
    return redirect('profile')

def course_detail(request, pk):
    course = get_object_or_404(Course, pk=pk)
    
    # 1. Считаем, сколько человек уже записано (со статусом 'active' или 'review')
    # Мы считаем и тех, кто на рассмотрении, чтобы не занять их места случайно
    occupied_count = Student.objects.filter(course=course, status__in=['active', 'review']).count()
    
    # 2. Вычисляем, сколько мест осталось
    remaining_slots = course.slots - occupied_count
    
    # 3. Проверяем, есть ли еще места
    is_full = remaining_slots <= 0

    return render(request, 'course_detail.html', {
        'course': course,
        'occupied_count': occupied_count,
        'remaining_slots': remaining_slots,
        'is_full': is_full
    })

@user_passes_test(lambda u: u.is_staff)
def admin_course_edit(request, pk=None):
    # Если pk есть — редактируем, если нет — создаем новый
    course = get_object_or_404(Course, pk=pk) if pk else None
    
    if request.method == "POST":
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = CourseForm(instance=course)
    
    return render(request, 'admin_course_form.html', {'form': form, 'course': course})

@user_passes_test(lambda u: u.is_staff)
def admin_course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    course.delete()
    return redirect('profile')